
public class Student {
    String name;
    int age;
    
    public void getName(){
        System.out.println(name);
    }  
}
